ko.version = "##VERSION##";

ko.exportSymbol('version', ko.version);
